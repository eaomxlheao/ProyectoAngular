export class Drink {
  idDrink: string;
  strDrink: string;
  strDrinkThumb: string;
  categoria: Number;
  precio: Number;
}
